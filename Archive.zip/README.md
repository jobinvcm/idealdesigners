This is not a commercial or free theme.

All the usage of this theme either free or commercial is strictly limited.